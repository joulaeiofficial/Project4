const els = {
  serverUrl: document.getElementById('serverUrl'),
  apiKey: document.getElementById('apiKey'),
  interval: document.getElementById('interval'),
  startBtn: document.getElementById('startBtn'),
  clearBtn: document.getElementById('clearBtn'),
  testConnBtn: document.getElementById('testConnBtn'),
  testNotifBtn: document.getElementById('testNotifBtn'),
  openLogBtn: document.getElementById('openLogBtn'),
  statusDot: document.getElementById('statusDot'),
  autoStartToggle: document.getElementById('autoStartToggle'),
  log: document.getElementById('log'),
};

let running = false;

const TAG_CLASS = {
  ok: 'text-success',
  err: 'text-err',
  warn: 'text-warn',
  hi: 'text-accent2 font-bold',
  dim: 'text-dim',
};

function appendLog(line, tag) {
  const div = document.createElement('div');
  div.className = TAG_CLASS[tag] || 'text-ink';
  div.textContent = line;
  els.log.appendChild(div);
  els.log.scrollTop = els.log.scrollHeight;
}

function safeInterval() {
  const v = parseInt(els.interval.value, 10);
  return v > 0 ? v : 15;
}

function setRunning(r) {
  running = r;
  if (r) {
    els.startBtn.textContent = 'توقف نظارت';
    els.startBtn.className =
      'px-6 py-2.5 rounded-xl font-bold text-sm text-white bg-err hover:bg-red-700 shadow-sm shadow-err/20 transition-colors';
    els.statusDot.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-success"></span> در حال اجرا';
    els.statusDot.className =
      'text-xs font-bold px-3 py-1.5 rounded-full bg-successSoft text-success flex items-center gap-1.5';
  } else {
    els.startBtn.textContent = 'شروع نظارت';
    els.startBtn.className =
      'px-6 py-2.5 rounded-xl font-bold text-sm text-white bg-accent hover:bg-accent2 shadow-sm shadow-accent/20 transition-colors';
    els.statusDot.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-dim"></span> متوقف';
    els.statusDot.className =
      'text-xs font-bold px-3 py-1.5 rounded-full bg-slate-100 text-dim flex items-center gap-1.5';
  }
}

async function init() {
  const cfg = await window.api.loadConfig();
  els.serverUrl.value = cfg.server_url;
  els.interval.value = cfg.interval;

  const autoStart = await window.api.getAutoStart();
  els.autoStartToggle.checked = !!autoStart;
}
init();

window.api.onLogLine(({ line, tag }) => appendLog(line, tag));
window.api.onStatusChanged(({ running: r }) => setRunning(r));

els.startBtn.addEventListener('click', async () => {
  if (running) {
    await window.api.stopMonitor();
    return;
  }
  const url = els.serverUrl.value.trim();
  if (!url) {
    alert('آدرس سرور را وارد کنید.');
    return;
  }
  await window.api.startMonitor({
    serverUrl: url,
    apiKey: els.apiKey.value.trim(),
    interval: safeInterval(),
  });
});

els.clearBtn.addEventListener('click', () => {
  els.log.innerHTML = '';
});

els.testConnBtn.addEventListener('click', () => {
  window.api.testConnection({
    serverUrl: els.serverUrl.value.trim(),
    apiKey: els.apiKey.value.trim(),
  });
});

els.testNotifBtn.addEventListener('click', () => {
  window.api.testNotification();
});

els.openLogBtn.addEventListener('click', () => {
  window.api.openLog();
});

els.autoStartToggle.addEventListener('change', () => {
  window.api.setAutoStart(els.autoStartToggle.checked);
});
