const { app, BrowserWindow, Tray, Menu, Notification, ipcMain, shell, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const axios = require('axios');

const isWin = process.platform === 'win32';

// برای اینکه کلیک روی نوتیفیکیشن از داخل Action Center (تاریخچه نوتیف‌های ویندوز)
// هم درست کار کند، باید AppUserModelID مشخص شود. بدون این، ویندوز نمی‌داند
// کلیک روی نوتیف قدیمی باید کدام برنامه را فعال کند.
if (isWin) {
  app.setAppUserModelId(process.execPath);
}

// ── تنظیمات پیش‌فرض ─────────────────────────────────────────────────────────
const DEFAULT_SERVER_URL = 'https://tarhjame.ir/it_status.php';
const DEFAULT_INTERVAL = 15;
const NOTIFICATION_CLICK_URL = 'https://tarhjame.ir/admin_login.php';
const TEHRAN_OFFSET_MIN = 3 * 60 + 30; // ایران دیگر ساعت تابستانی ندارد؛ همیشه +۳:۳۰

const userDataDir = app.getPath('userData');
const CONFIG_FILE = path.join(userDataDir, 'it_alert_client_config.json');
const LOG_FILE = path.join(userDataDir, 'it_alerts_client.log');

let mainWindow = null;
let tray = null;
let monitorTimer = null;
let running = false;
let lastKnownId = 0;

// سایت داخلی از گواهی SSL self-signed استفاده می‌کند
const insecureAgent = new https.Agent({ rejectUnauthorized: false });

// ── اجرای خودکار هنگام ورود به ویندوز ────────────────────────────────────────
function getAutoLaunch() {
  try {
    return app.getLoginItemSettings().openAtLogin;
  } catch {
    return false;
  }
}

function setAutoLaunch(enabled) {
  try {
    app.setLoginItemSettings({
      openAtLogin: enabled,
      args: enabled ? ['--minimized'] : [],
    });
  } catch (e) {
    /* ignore */
  }
}

// ── تنظیمات ذخیره‌شده (کلید API هرگز ذخیره نمی‌شود) ────────────────────────
function loadConfig() {
  try {
    const raw = fs.readFileSync(CONFIG_FILE, 'utf-8');
    const cfg = JSON.parse(raw);
    return {
      server_url: cfg.server_url || DEFAULT_SERVER_URL,
      interval: Number(cfg.interval) > 0 ? Number(cfg.interval) : DEFAULT_INTERVAL,
    };
  } catch {
    return { server_url: DEFAULT_SERVER_URL, interval: DEFAULT_INTERVAL };
  }
}

function saveConfig(cfg) {
  try {
    fs.writeFileSync(
      CONFIG_FILE,
      JSON.stringify({ server_url: cfg.server_url, interval: cfg.interval }, null, 2),
      'utf-8'
    );
  } catch (e) {
    /* ignore */
  }
}

function appendLogFile(line) {
  try {
    fs.appendFileSync(LOG_FILE, line + '\n', 'utf-8');
  } catch (e) {
    /* ignore */
  }
}

function sendLog(msg, tag) {
  const ts = new Date().toLocaleTimeString('en-GB', { hour12: false });
  const line = `[${ts}] ${msg}`;
  appendLogFile(line);
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('log:line', { line, tag });
  }
}

// تبدیل زمان UTC خام سرور به ساعت تهران (+۳:۳۰) — همان کاری که config.php می‌کند
function toTehranTime(createdAtStr) {
  if (!createdAtStr) return createdAtStr;
  try {
    const [datePart, timePart] = createdAtStr.split(' ');
    const [y, m, d] = datePart.split('-').map(Number);
    const [hh, mm, ss] = timePart.split(':').map(Number);
    const utcMs = Date.UTC(y, m - 1, d, hh, mm, ss);
    const tehranMs = utcMs + TEHRAN_OFFSET_MIN * 60 * 1000;
    const dt = new Date(tehranMs);
    const pad = (n) => String(n).padStart(2, '0');
    return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())} ${pad(
      dt.getUTCHours()
    )}:${pad(dt.getUTCMinutes())}:${pad(dt.getUTCSeconds())}`;
  } catch {
    return createdAtStr;
  }
}

function buildUrl(serverUrl, apiKey) {
  let url = (serverUrl || '').trim();
  const key = (apiKey || '').trim();
  if (key) {
    const sep = url.includes('?') ? '&' : '?';
    url = `${url}${sep}key=${encodeURIComponent(key)}`;
  }
  return url;
}

async function httpGetJson(url) {
  const res = await axios.get(url, { timeout: 8000, httpsAgent: insecureAgent });
  return res.data;
}

function findChromePath() {
  if (!isWin) return null;
  const candidates = [
    path.join(process.env['PROGRAMFILES'] || 'C:\\Program Files', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(
      process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)',
      'Google',
      'Chrome',
      'Application',
      'chrome.exe'
    ),
    path.join(process.env['LOCALAPPDATA'] || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
  ];
  for (const c of candidates) {
    if (c && fs.existsSync(c)) return c;
  }
  return null;
}

function openInChrome(url) {
  const chromePath = findChromePath();
  try {
    if (chromePath) {
      require('child_process').spawn(chromePath, [url], { detached: true, stdio: 'ignore' }).unref();
    } else {
      sendLog('⚠️ مسیر گوگل کروم پیدا نشد؛ لینک با مرورگر پیش‌فرض باز می‌شود.', 'warn');
      shell.openExternal(url);
    }
    sendLog(`🌐 لینک باز شد: ${url}`, 'ok');
  } catch (e) {
    sendLog(`❌ خطا در باز کردن لینک: ${e.message}`, 'err');
  }
}

function playAlertSound() {
  try {
    shell.beep();
  } catch (e) {
    /* ignore */
  }
}

// نگه‌داشتن رفرنس نوتیفیکیشن‌های فعال، تا زمانی که کاربر کلیک نکرده یا بسته نشده‌اند
// از حافظه پاک (Garbage Collect) نشوند؛ در غیر این صورت کلیک از Action Center
// ممکن است بی‌اثر بماند چون listener دیگر وجود ندارد.
const activeNotifications = [];

function showNotification(title, message, clickUrl) {
  if (!Notification.isSupported()) {
    sendLog('❌ این سیستم از نوتیفیکیشن پشتیبانی نمی‌کند.', 'err');
    return;
  }
  const n = new Notification({
    title,
    body: message,
    icon: path.join(__dirname, 'assets', 'icon.png'),
  });

  const removeFromActive = () => {
    const idx = activeNotifications.indexOf(n);
    if (idx !== -1) activeNotifications.splice(idx, 1);
  };

  n.on('click', () => {
    openInChrome(clickUrl || NOTIFICATION_CLICK_URL);
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
    removeFromActive();
  });
  n.on('close', removeFromActive);

  activeNotifications.push(n);
  n.show();
  sendLog(`✅ نوتیفیکیشن نمایش داده شد (کلیک‌پذیر): ${title}`, 'ok');
}

// ── منطق چک کردن سرور ───────────────────────────────────────────────────────
async function checkNewRequests(serverUrl, apiKey) {
  try {
    const data = await httpGetJson(buildUrl(serverUrl, apiKey));
    if (!data.ok) {
      sendLog(`❌ خطای سرور: ${data.error}`, 'err');
      return;
    }
    const latest = data.latest;
    if (latest) {
      const latestId = latest.id;
      const title = latest.title;
      const createdAt = latest.created_at;
      if (latestId > lastKnownId && lastKnownId !== 0) {
        sendLog(`🔔 درخواست جدید شناسایی شد: ID=${latestId}, عنوان=${title}`, 'hi');
        showNotification('🔔 درخواست جدید IT', `عنوان: ${title}\nزمان: ${toTehranTime(createdAt)}`);
        playAlertSound();
      }
      lastKnownId = latestId;
    }
  } catch (e) {
    sendLog(`❌ خطا در اتصال به سرور: ${e.message}`, 'err');
  }
}

// ── حلقه نظارت ───────────────────────────────────────────────────────────────
function startMonitor(serverUrl, apiKey, interval) {
  if (running) return;
  running = true;
  lastKnownId = 0;
  sendLog('🚀 نظارت آغاز شد', 'ok');
  sendLog(`🌐 آدرس سرور: ${serverUrl}`, 'dim');
  sendLog(`⏱️ فاصله بررسی: ${interval} ثانیه`, 'dim');

  const tick = async () => {
    await checkNewRequests(serverUrl, apiKey);
    if (running) {
      monitorTimer = setTimeout(tick, interval * 1000);
    }
  };
  tick();
  if (mainWindow) mainWindow.webContents.send('status:changed', { running: true });
}

function stopMonitor() {
  if (!running) return;
  running = false;
  if (monitorTimer) clearTimeout(monitorTimer);
  monitorTimer = null;
  sendLog('⏹️ نظارت متوقف شد', 'warn');
  if (mainWindow) mainWindow.webContents.send('status:changed', { running: false });
}

// ── پنجره اصلی ───────────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 780,
    height: 680,
    minWidth: 680,
    minHeight: 540,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    autoHideMenuBar: true,
    backgroundColor: '#9a9eb0',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // با زدن دکمه X، پنجره فقط مخفی می‌شود و برنامه در پس‌زمینه ادامه می‌یابد
  mainWindow.on('close', (e) => {
    if (!app.isQuiting) {
      e.preventDefault();
      mainWindow.hide();
      if (isWin && tray) {
        try {
          tray.displayBalloon({
            title: 'IT Request Monitor',
            content: 'برنامه در پس‌زمینه (کنار ساعت) در حال اجراست.',
          });
        } catch (err) {
          /* ignore */
        }
      }
    }
  });
}

// ── آیکون کنار ساعت (Tray) ───────────────────────────────────────────────────
function createTray() {
  const icon = nativeImage.createFromPath(path.join(__dirname, 'assets', 'icon.png'));
  tray = new Tray(icon.resize({ width: 16, height: 16 }));
  tray.setToolTip('IT Request Monitor');
  const menu = Menu.buildFromTemplate([
    { label: 'نمایش/مخفی‌کردن پنجره', click: toggleWindow },
    { label: 'خروج کامل', click: () => { app.isQuiting = true; app.quit(); } },
  ]);
  tray.setContextMenu(menu);
  tray.on('click', toggleWindow);
}

function toggleWindow() {
  if (!mainWindow) return;
  if (mainWindow.isVisible()) {
    mainWindow.hide();
  } else {
    mainWindow.show();
    mainWindow.focus();
  }
}

// ── چرخه‌ی برنامه ─────────────────────────────────────────────────────────────
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    // اولین بار که برنامه اجرا می‌شود (هنوز فایل تنظیمات ساخته نشده)،
    // اجرای خودکار هنگام ورود به ویندوز به‌صورت پیش‌فرض فعال می‌شود.
    const isFirstRun = !fs.existsSync(CONFIG_FILE);
    if (isFirstRun) {
      setAutoLaunch(true);
    }

    createWindow();
    createTray();
    // اگر با --minimized اجرا شده باشد (مثلاً هنگام استارت ویندوز)، پنجره مخفی می‌ماند.
    // نظارت خودکار شروع نمی‌شود چون کلید API ذخیره نمی‌شود و باید دستی وارد شود.
    if (process.argv.includes('--minimized')) {
      mainWindow.hide();
    }
  });

  app.on('window-all-closed', () => {
    // در ویندوز/لینوکس برنامه در تری باقی می‌ماند؛ خروج کامل فقط از منوی تری
  });

  app.on('before-quit', () => {
    app.isQuiting = true;
    stopMonitor();
  });
}

// ── IPC ──────────────────────────────────────────────────────────────────────
ipcMain.handle('config:load', () => loadConfig());
ipcMain.handle('config:save', (e, cfg) => {
  saveConfig(cfg);
  return true;
});

ipcMain.handle('monitor:start', (e, { serverUrl, apiKey, interval }) => {
  saveConfig({ server_url: serverUrl, interval });
  startMonitor(serverUrl, apiKey, interval);
  return true;
});

ipcMain.handle('monitor:stop', () => {
  stopMonitor();
  return true;
});

ipcMain.handle('monitor:test-connection', async (e, { serverUrl, apiKey }) => {
  try {
    const data = await httpGetJson(buildUrl(serverUrl, apiKey));
    if (data.ok) {
      sendLog('✅ اتصال به سرور موفق بود.', 'ok');
    } else {
      sendLog(`⚠️ سرور خطا برگرداند: ${data.error}`, 'warn');
    }
  } catch (err) {
    sendLog(`❌ اتصال به سرور ناموفق: ${err.message}`, 'err');
  }
});

ipcMain.handle('monitor:test-notification', () => {
  showNotification('🔔 تست نوتیفیکیشن', 'این یک پیام آزمایشی است. برای باز شدن لینک کلیک کنید.');
  playAlertSound();
});

ipcMain.handle('autostart:get', () => getAutoLaunch());
ipcMain.handle('autostart:set', (e, enabled) => {
  setAutoLaunch(enabled);
  sendLog(
    enabled ? '✅ اجرای خودکار هنگام ورود به ویندوز فعال شد.' : '⏹️ اجرای خودکار هنگام ورود به ویندوز غیرفعال شد.',
    enabled ? 'ok' : 'dim'
  );
  return true;
});

ipcMain.handle('log:open', () => {
  if (fs.existsSync(LOG_FILE)) {
    shell.openPath(LOG_FILE);
  } else {
    sendLog('هنوز فایل لاگی ساخته نشده است.', 'warn');
  }
});