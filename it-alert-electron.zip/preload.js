const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  loadConfig: () => ipcRenderer.invoke('config:load'),
  saveConfig: (cfg) => ipcRenderer.invoke('config:save', cfg),
  startMonitor: (args) => ipcRenderer.invoke('monitor:start', args),
  stopMonitor: () => ipcRenderer.invoke('monitor:stop'),
  testConnection: (args) => ipcRenderer.invoke('monitor:test-connection', args),
  testNotification: () => ipcRenderer.invoke('monitor:test-notification'),
  openLog: () => ipcRenderer.invoke('log:open'),
  getAutoStart: () => ipcRenderer.invoke('autostart:get'),
  setAutoStart: (enabled) => ipcRenderer.invoke('autostart:set', enabled),
  onLogLine: (cb) => ipcRenderer.on('log:line', (_e, data) => cb(data)),
  onStatusChanged: (cb) => ipcRenderer.on('status:changed', (_e, data) => cb(data)),
});
